package tb.homework.TeaBiscuits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeaBiscuitsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeaBiscuitsApplication.class, args);
	}

}
